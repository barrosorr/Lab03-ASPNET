﻿using System;
namespace Lab03_ASPNET.Models
{
    public class YourModel
    {
        public int pid { get; set; }
        public string productname { get; set; }
        public int price { get; set; }
        public int productid { get; set; }

    }
}
